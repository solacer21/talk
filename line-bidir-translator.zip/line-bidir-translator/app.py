import os, json
from pathlib import Path
from flask import Flask, request, abort
from dotenv import load_dotenv
from langdetect import detect
from translator import translate, normalize_lang
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage, JoinEvent
)

load_dotenv()

CHANNEL_SECRET = os.getenv("LINE_CHANNEL_SECRET")
CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN")
DEFAULT_TARGET = os.getenv("DEFAULT_TARGET", "zh-TW")

if CHANNEL_SECRET is None or CHANNEL_ACCESS_TOKEN is None:
    raise RuntimeError("Please set LINE_CHANNEL_SECRET and LINE_CHANNEL_ACCESS_TOKEN in .env")

app = Flask(__name__)
line_bot_api = LineBotApi(CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(CHANNEL_SECRET)

PREF_PATH = Path("user_langs.json")
if not PREF_PATH.exists():
    PREF_PATH.write_text("{}", encoding="utf-8")

def load_prefs():
    try:
        return json.loads(PREF_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_prefs(prefs):
    PREF_PATH.write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")

HELP_TEXT = (
    "指令：\n"
    "/lang <code>  設定你偏好的語言（例：/lang en、/lang zh-TW、/lang ja、/lang th）\n"
    "/mylang       查看你的設定\n"
    "/help         顯示此說明\n"
    "把我加進群組後，我會把大家的訊息翻成多語貼在群組中。"
)

@app.route("/callback", methods=["POST"])
def callback():
    signature = request.headers.get("X-Line-Signature", "")
    body = request.get_data(as_text=True)
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return "OK"

@handler.add(JoinEvent)
def handle_join(event):
    welcome = (
        "大家好，我是雙向翻譯助手（個人測試版）！\n"
        "用 `/lang <code>` 設定你的偏好語言，例如：/lang en、/lang zh-TW。\n"
        "之後我會把訊息翻成 zh-TW / en / ja / th 貼在群組中。輸入 /help 取得說明。"
    )
    line_bot_api.reply_message(event.reply_token, TextSendMessage(text=welcome))

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    text = event.message.text.strip()
    user_id = event.source.user_id if hasattr(event.source, "user_id") else None

    prefs = load_prefs()
    if user_id and user_id not in prefs:
        prefs[user_id] = {"target": DEFAULT_TARGET}
        save_prefs(prefs)

    # Commands
    if text.lower().startswith("/help"):
        line_bot_api.reply_message(event.reply_token, TextSendMessage(text=HELP_TEXT))
        return

    if text.lower().startswith("/mylang"):
        target = prefs.get(user_id, {}).get("target", DEFAULT_TARGET)
        line_bot_api.reply_message(event.reply_token, TextSendMessage(text=f"你的偏好：{target}"))
        return

    if text.lower().startswith("/lang"):
        parts = text.split(maxsplit=1)
        if len(parts) == 2:
            code = normalize_lang(parts[1])
            prefs[user_id] = {"target": code}
            save_prefs(prefs)
            line_bot_api.reply_message(event.reply_token, TextSendMessage(text=f"OK！你的偏好語言改為：{code}"))
        else:
            line_bot_api.reply_message(event.reply_token, TextSendMessage(text="用法：/lang <code> 例如 /lang en"))
        return

    # Translation fan-out to group (zh-TW, en, ja, th)
    try:
        src = detect(text)
    except Exception:
        src = "auto"
    targets = ["zh-TW", "en", "ja", "th"]
    out_lines = [f"[原文 {src}] {text}"]
    for tgt in targets:
        if tgt.lower().startswith(src.lower()):  # 若同語言就跳過
            continue
        try:
            tr = translate(text, target_lang=tgt, src_lang="auto")
            out_lines.append(f"[{tgt}] {tr}")
        except Exception as e:
            out_lines.append(f"[{tgt}] <翻譯失敗: {e}>")

    reply_text = "\n".join(out_lines[:10])
    line_bot_api.reply_message(event.reply_token, TextSendMessage(text=reply_text))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
